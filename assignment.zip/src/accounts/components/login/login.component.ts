import { Component, Inject } from '@angular/core';
import {ILoggerService} from 'src/services/iLogger.service';


@Component({
    templateUrl:'./login.component.html',
    selector:'login-comp'
})
export default class LoginComponent{


    userName:String;
    password:String;
    message:String;
    loggerService:ILoggerService;
    //Constructor Injection
    constructor(/*Dependency*/ loggerService:ILoggerService){
        this.userName="";
        this.password="";
        this.message="";
        this.loggerService=loggerService;
    }

    onUserNameEdit(value){
            this.userName=value;
    }
    onPasswordEdit(value){

        this.password=value;
    }
    onLoginButtonClick(){
        if(this.userName=="admin" && this.password=="admin@123"){
            this.message="Login Successfull";
            this.loggerService.write("Login Successfull");
        }
        else{
            this.message="Invalid Credentials";
            this.loggerService.write("Invalid Credentials");
        }
    }
    onClearButtonClick(){
        this.userName="";
        this.password="";
        this.message="";

    }
}