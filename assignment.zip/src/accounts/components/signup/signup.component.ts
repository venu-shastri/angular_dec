export class SignupComponent{

    userName:String;
    password:String;
    email:String;
    constructor(){

    }

    onSignupButtonClick(){

    }

    onClearButtonClick(){
        
    }
}