import {NgModule} from '@angular/core'
import HeaderComponent from './components/header/header.component'
import { BrowserModule } from '@angular/platform-browser'
import ConsoleLoggerService from '../services/consoleLogger.service'
import {ILoggerService} from 'src/services/iLogger.service';

@NgModule({

    declarations:[HeaderComponent],
    bootstrap:[HeaderComponent],
    imports:[BrowserModule,AccountsModule
    ],
    providers:[
        {provide:ILoggerService,useClass:ConsoleLoggerService},
       
    ]
})
export default class AppModule
{

}