
import {Component} from '@angular/core'

@Component({
    templateUrl:'./header.component.html',
    selector:'header-comp'
})
export default class HeaderComponent{

    //logic only
}