import {ILoggerService} from './iLogger.service'
export default class ConsoleLoggerService extends ILoggerService{

    constructor(){
        super();
        console.log("ConsoleLoggerService Instantiated");
    }
    write(message){

        console.log(message);
    }

}