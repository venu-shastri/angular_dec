export  abstract class ILoggerService{

    abstract write(message):void;
}